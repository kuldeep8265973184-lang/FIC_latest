import { Router } from "express";
import { getAllExams, createExam, updateExam, deleteExam } from "../controllers/exam.controller.js";
import { protectAdmin } from "../middleware/auth.js";

const router = Router();
router.use(protectAdmin);

router.get("/", getAllExams);
router.post("/", createExam);
router.put("/:id", updateExam);
router.delete("/:id", deleteExam);

export default router;
