import { Router } from "express";
import {
  signup,
  login,
  getMe,
  forgotPassword,
  resetPassword,
} from "../controllers/studentAuth.controller.js";
import {
  signupValidationRules,
  loginValidationRules,
  forgotPasswordValidationRules,
  resetPasswordValidationRules,
} from "../validators/studentAuth.validator.js";
import validate from "../middleware/validate.js";
import { protectStudent } from "../middleware/auth.js";

const router = Router();

router.post("/signup", signupValidationRules, validate, signup);
router.post("/login", loginValidationRules, validate, login);
router.get("/me", protectStudent, getMe);
router.post("/forgot-password", forgotPasswordValidationRules, validate, forgotPassword);
router.post("/reset-password", resetPasswordValidationRules, validate, resetPassword);

export default router;
