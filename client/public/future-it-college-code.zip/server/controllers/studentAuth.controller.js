import crypto from "crypto";
import Student from "../models/Student.js";
import asyncHandler from "../utils/asyncHandler.js";
import ApiResponse from "../utils/ApiResponse.js";
import ApiError from "../utils/ApiError.js";
import { generateToken } from "../utils/generateToken.js";

const publicStudent = (student) => ({
  id: student._id,
  name: student.name,
  email: student.email,
  phone: student.phone,
  address: student.address,
  course: student.course,
  createdAt: student.createdAt,
});

/**
 * @route POST /api/student/auth/signup
 */
export const signup = asyncHandler(async (req, res) => {
  const { name, email, phone, password, address, course } = req.body;

  const existing = await Student.findOne({ email: email.toLowerCase() });
  if (existing) throw new ApiError(409, "An account with this email already exists");

  const student = await Student.create({ name, email, phone, password, address, course });
  const token = generateToken(student._id, "student");

  return res
    .status(201)
    .json(new ApiResponse(201, { token, student: publicStudent(student) }, "Account created successfully"));
});

/**
 * @route POST /api/student/auth/login
 */
export const login = asyncHandler(async (req, res) => {
  const { email, password } = req.body;

  const student = await Student.findOne({ email: email.toLowerCase() }).select("+password");
  if (!student) throw new ApiError(401, "Invalid email or password");
  if (!student.isActive) throw new ApiError(403, "This account has been disabled. Please contact the institute.");

  const isMatch = await student.comparePassword(password);
  if (!isMatch) throw new ApiError(401, "Invalid email or password");

  const token = generateToken(student._id, "student");

  return res.status(200).json(new ApiResponse(200, { token, student: publicStudent(student) }, "Login successful"));
});

/**
 * @route GET /api/student/auth/me
 */
export const getMe = asyncHandler(async (req, res) => {
  return res.status(200).json(new ApiResponse(200, publicStudent(req.student)));
});

/**
 * @route POST /api/student/auth/forgot-password
 * Architecture ready: generates a reset token and (if email is configured)
 * emails a reset link. Does not reveal whether the email exists.
 */
export const forgotPassword = asyncHandler(async (req, res) => {
  const { email } = req.body;
  const student = await Student.findOne({ email: email.toLowerCase() });

  if (student) {
    const resetToken = crypto.randomBytes(32).toString("hex");
    student.resetPasswordToken = crypto.createHash("sha256").update(resetToken).digest("hex");
    student.resetPasswordExpires = Date.now() + 60 * 60 * 1000; // 1 hour
    await student.save();
    // Email sending is architecture-ready via services/email.service.js;
    // wire up sendPasswordResetEmail(student, resetToken) once SMTP creds are set.
  }

  return res
    .status(200)
    .json(new ApiResponse(200, null, "If an account exists for this email, a reset link has been sent."));
});

/**
 * @route POST /api/student/auth/reset-password
 */
export const resetPassword = asyncHandler(async (req, res) => {
  const { token, password } = req.body;
  const hashed = crypto.createHash("sha256").update(token).digest("hex");

  const student = await Student.findOne({
    resetPasswordToken: hashed,
    resetPasswordExpires: { $gt: Date.now() },
  }).select("+resetPasswordToken +resetPasswordExpires");

  if (!student) throw new ApiError(400, "Reset link is invalid or has expired");

  student.password = password;
  student.resetPasswordToken = undefined;
  student.resetPasswordExpires = undefined;
  await student.save();

  return res.status(200).json(new ApiResponse(200, null, "Password reset successful — please log in"));
});
