import Exam from "../models/Exam.js";
import asyncHandler from "../utils/asyncHandler.js";
import ApiResponse from "../utils/ApiResponse.js";
import ApiError from "../utils/ApiError.js";

/**
 * @route GET /api/exams
 * @desc  List active exams — used by the Student Dashboard
 *        ("My Tests" / "Upcoming Tests").
 * @access Student
 */
export const getActiveExams = asyncHandler(async (req, res) => {
  const exams = await Exam.find({ isActive: true }).sort({ createdAt: -1 });
  return res.status(200).json(new ApiResponse(200, exams));
});

/**
 * @route GET /api/exams/:id
 * @access Student
 */
export const getExamById = asyncHandler(async (req, res) => {
  const exam = await Exam.findById(req.params.id);
  if (!exam || !exam.isActive) throw new ApiError(404, "Test not found or is no longer active");
  return res.status(200).json(new ApiResponse(200, exam));
});

/**
 * @route GET /api/admin/exams
 * @access Admin
 */
export const getAllExams = asyncHandler(async (req, res) => {
  const exams = await Exam.find().populate("categoryDistribution.category", "name").sort({ createdAt: -1 });
  return res.status(200).json(new ApiResponse(200, exams));
});

/**
 * @route POST /api/admin/exams
 * @desc  Create Test — Test Name, Duration, Number of Questions, Topic,
 *        Passing Marks, Active/Inactive, plus optional category distribution
 *        for the Test Generator (e.g. Computer Fundamentals -> 15, MS Word -> 5).
 * @access Admin
 */
export const createExam = asyncHandler(async (req, res) => {
  const {
    name,
    description,
    durationMinutes,
    totalQuestions,
    topic,
    difficulty,
    passingPercentage,
    categoryDistribution,
    allowRetest,
    showExplanationAfterSubmit,
    isActive,
  } = req.body;

  if (!name || !durationMinutes || !totalQuestions) {
    throw new ApiError(400, "Test name, duration and number of questions are required");
  }

  if (categoryDistribution?.length) {
    const distributionTotal = categoryDistribution.reduce((sum, d) => sum + Number(d.count || 0), 0);
    if (distributionTotal !== Number(totalQuestions)) {
      throw new ApiError(
        400,
        `Category distribution (${distributionTotal}) must add up to the total number of questions (${totalQuestions})`
      );
    }
  }

  const exam = await Exam.create({
    name,
    description,
    durationMinutes,
    totalQuestions,
    topic,
    difficulty,
    passingPercentage,
    categoryDistribution,
    allowRetest,
    showExplanationAfterSubmit,
    isActive,
    createdBy: req.admin._id,
  });

  return res.status(201).json(new ApiResponse(201, exam, "Test created successfully"));
});

/**
 * @route PUT /api/admin/exams/:id
 * @access Admin
 */
export const updateExam = asyncHandler(async (req, res) => {
  const exam = await Exam.findByIdAndUpdate(req.params.id, req.body, { new: true, runValidators: true });
  if (!exam) throw new ApiError(404, "Test not found");
  return res.status(200).json(new ApiResponse(200, exam, "Test updated"));
});

/**
 * @route DELETE /api/admin/exams/:id
 * @access Admin
 */
export const deleteExam = asyncHandler(async (req, res) => {
  const exam = await Exam.findByIdAndDelete(req.params.id);
  if (!exam) throw new ApiError(404, "Test not found");
  return res.status(200).json(new ApiResponse(200, null, "Test deleted"));
});
