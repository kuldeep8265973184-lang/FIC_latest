import mongoose from "mongoose";

/**
 * A reusable Exam/Test template configured by the Admin.
 * `categoryDistribution` allows building a paper like:
 * Computer Fundamentals -> 15, MS Word -> 5, etc. (Test Generator).
 * If left empty, questions are pulled from `topic`/overall pool instead.
 */
const ExamSchema = new mongoose.Schema(
  {
    name: { type: String, required: true, trim: true },
    description: { type: String, trim: true, default: "" },
    durationMinutes: { type: Number, required: true, default: 15 },
    totalQuestions: { type: Number, required: true, default: 50 },
    topic: { type: String, trim: true, default: "Basic Computer" },
    difficulty: { type: String, enum: ["Easy", "Medium", "Hard", "Mixed"], default: "Mixed" },
    passingPercentage: { type: Number, default: 60 },
    categoryDistribution: [
      {
        category: { type: mongoose.Schema.Types.ObjectId, ref: "Category" },
        count: { type: Number, required: true },
      },
    ],
    allowRetest: { type: Boolean, default: false },
    showExplanationAfterSubmit: { type: Boolean, default: true },
    isActive: { type: Boolean, default: true },
    createdBy: { type: mongoose.Schema.Types.ObjectId, ref: "Admin" },
  },
  { timestamps: true }
);

export default mongoose.model("Exam", ExamSchema);
