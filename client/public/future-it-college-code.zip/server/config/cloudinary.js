import { v2 as cloudinary } from "cloudinary";

/**
 * Cloudinary configuration — architecture ready for future use.
 * Image uploads currently fall back to local disk storage (see
 * middleware/upload.js) when Cloudinary credentials are not set.
 */
const isCloudinaryConfigured =
  !!process.env.CLOUDINARY_CLOUD_NAME &&
  !!process.env.CLOUDINARY_API_KEY &&
  !!process.env.CLOUDINARY_API_SECRET;

if (isCloudinaryConfigured) {
  cloudinary.config({
    cloud_name: process.env.CLOUDINARY_CLOUD_NAME,
    api_key: process.env.CLOUDINARY_API_KEY,
    api_secret: process.env.CLOUDINARY_API_SECRET,
  });
}

export { isCloudinaryConfigured };
export default cloudinary;
