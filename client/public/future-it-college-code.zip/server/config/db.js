import mongoose from "mongoose";

/**
 * Establishes connection to MongoDB using Mongoose.
 * Exits the process if the connection fails since the API
 * cannot serve data reliably without a database connection.
 */
const connectDB = async () => {
  try {
    const uri = process.env.MONGODB_URI || "mongodb://127.0.0.1:27017/future-it-college";
    const conn = await mongoose.connect(uri);
    console.log(`MongoDB connected: ${conn.connection.host}/${conn.connection.name}`);
  } catch (error) {
    console.error(`MongoDB connection error: ${error.message}`);
    process.exit(1);
  }
};

export default connectDB;
