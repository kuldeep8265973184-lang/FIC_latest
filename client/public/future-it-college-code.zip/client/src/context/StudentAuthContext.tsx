import { createContext, useContext, useEffect, useState, type ReactNode } from "react";
import type { Student, StudentLoginData, StudentSignupData } from "@/types/portal";
import { studentLogin, studentSignup, getStudentMe } from "@/services/api/studentAuth.service";
import { STUDENT_TOKEN_KEY, STUDENT_DATA_KEY } from "@/services/api/axiosInstance";

interface StudentAuthContextValue {
  student: Student | null;
  isLoading: boolean;
  isAuthenticated: boolean;
  login: (payload: StudentLoginData) => Promise<void>;
  signup: (payload: StudentSignupData) => Promise<void>;
  logout: () => void;
}

const StudentAuthContext = createContext<StudentAuthContextValue | undefined>(undefined);

export const StudentAuthProvider = ({ children }: { children: ReactNode }) => {
  const [student, setStudent] = useState<Student | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const token = localStorage.getItem(STUDENT_TOKEN_KEY);
    const cached = localStorage.getItem(STUDENT_DATA_KEY);

    if (!token) {
      setIsLoading(false);
      return;
    }

    if (cached) setStudent(JSON.parse(cached));

    // Verify the token is still valid and refresh the cached profile.
    getStudentMe()
      .then((data) => {
        setStudent(data);
        localStorage.setItem(STUDENT_DATA_KEY, JSON.stringify(data));
      })
      .catch(() => {
        localStorage.removeItem(STUDENT_TOKEN_KEY);
        localStorage.removeItem(STUDENT_DATA_KEY);
        setStudent(null);
      })
      .finally(() => setIsLoading(false));
  }, []);

  const login = async (payload: StudentLoginData) => {
    const data = await studentLogin(payload);
    if (!data) return;
    localStorage.setItem(STUDENT_TOKEN_KEY, data.token);
    localStorage.setItem(STUDENT_DATA_KEY, JSON.stringify(data.student));
    setStudent(data.student);
  };

  const signup = async (payload: StudentSignupData) => {
    const data = await studentSignup(payload);
    if (!data) return;
    localStorage.setItem(STUDENT_TOKEN_KEY, data.token);
    localStorage.setItem(STUDENT_DATA_KEY, JSON.stringify(data.student));
    setStudent(data.student);
  };

  const logout = () => {
    localStorage.removeItem(STUDENT_TOKEN_KEY);
    localStorage.removeItem(STUDENT_DATA_KEY);
    setStudent(null);
  };

  return (
    <StudentAuthContext.Provider value={{ student, isLoading, isAuthenticated: !!student, login, signup, logout }}>
      {children}
    </StudentAuthContext.Provider>
  );
};

export const useStudentAuth = () => {
  const ctx = useContext(StudentAuthContext);
  if (!ctx) throw new Error("useStudentAuth must be used within a StudentAuthProvider");
  return ctx;
};
