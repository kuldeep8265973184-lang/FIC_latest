import { useEffect, useState } from "react";
import AdminLayout from "@/components/admin/AdminLayout";
import { fetchCategories } from "@/services/api/category.service";
import { fetchAllExams, createExam, updateExam, deleteExam } from "@/services/api/adminExam.service";
import type { Category, ExamConfig } from "@/types";

interface DistRow { category: string; count: number }

const AdminExams = () => {
  const [exams, setExams] = useState<ExamConfig[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [showForm, setShowForm] = useState(false);
  const [name, setName] = useState("");
  const [duration, setDuration] = useState(15);
  const [totalQuestions, setTotalQuestions] = useState(50);
  const [topic, setTopic] = useState("Basic Computer");
  const [passingPercentage, setPassingPercentage] = useState(60);
  const [distribution, setDistribution] = useState<DistRow[]>([]);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const load = () => fetchAllExams().then((e) => setExams(e || []));
  useEffect(() => {
    load();
    fetchCategories().then((c) => setCategories(c || []));
  }, []);

  const distTotal = distribution.reduce((sum, d) => sum + Number(d.count || 0), 0);

  const addDistRow = () => setDistribution((d) => [...d, { category: "", count: 0 }]);
  const updateDistRow = (i: number, patch: Partial<DistRow>) =>
    setDistribution((d) => d.map((row, idx) => (idx === i ? { ...row, ...patch } : row)));
  const removeDistRow = (i: number) => setDistribution((d) => d.filter((_, idx) => idx !== i));

  const handleCreate = async () => {
    setError("");
    if (distribution.length > 0 && distTotal !== totalQuestions) {
      setError(`Category distribution (${distTotal}) must add up to total questions (${totalQuestions})`);
      return;
    }
    setLoading(true);
    try {
      await createExam({
        name,
        durationMinutes: duration,
        totalQuestions,
        topic,
        difficulty: "Mixed",
        passingPercentage,
        categoryDistribution: distribution.filter((d) => d.category && d.count > 0),
        isActive: true,
      });
      setShowForm(false);
      setName("");
      setDistribution([]);
      load();
    } catch (err: any) {
      setError(err?.response?.data?.message || "Could not create test");
    } finally {
      setLoading(false);
    }
  };

  const toggleActive = async (exam: ExamConfig) => {
    await updateExam(exam._id, { isActive: !exam.isActive });
    load();
  };

  const handleDelete = async (id: string) => {
    if (!confirm("Delete this test?")) return;
    await deleteExam(id);
    load();
  };

  return (
    <AdminLayout title="Test Management">
      <div className="flex justify-end mb-6">
        <button onClick={() => setShowForm((s) => !s)} className="btn btn-primary btn-sm">
          {showForm ? "Cancel" : "+ Create Test"}
        </button>
      </div>

      {showForm && (
        <div className="card p-6 mb-8 space-y-5">
          <h2 className="font-display font-semibold text-lg">Create New Test</h2>
          <div className="grid sm:grid-cols-2 gap-4">
            <div>
              <label className="f-label">Test Name</label>
              <input className="field" value={name} onChange={(e) => setName(e.target.value)} />
            </div>
            <div>
              <label className="f-label">Topic</label>
              <input className="field" value={topic} onChange={(e) => setTopic(e.target.value)} />
            </div>
            <div>
              <label className="f-label">Duration (minutes)</label>
              <input className="field" type="number" value={duration} onChange={(e) => setDuration(Number(e.target.value))} />
            </div>
            <div>
              <label className="f-label">Number of Questions</label>
              <input className="field" type="number" value={totalQuestions} onChange={(e) => setTotalQuestions(Number(e.target.value))} />
            </div>
            <div>
              <label className="f-label">Passing Marks (%)</label>
              <input className="field" type="number" value={passingPercentage} onChange={(e) => setPassingPercentage(Number(e.target.value))} />
            </div>
          </div>

          <div>
            <div className="flex items-center justify-between mb-2">
              <label className="f-label mb-0">Category Distribution (Test Generator) — optional</label>
              <button type="button" onClick={addDistRow} className="text-[12.5px] text-[var(--royal)] font-semibold hover:underline">
                + Add Row
              </button>
            </div>
            <div className="space-y-2">
              {distribution.map((row, i) => (
                <div key={i} className="flex gap-2">
                  <select className="field" value={row.category} onChange={(e) => updateDistRow(i, { category: e.target.value })}>
                    <option value="">Select category</option>
                    {categories.map((c) => (
                      <option key={c._id} value={c._id}>{c.name}</option>
                    ))}
                  </select>
                  <input
                    className="field w-28"
                    type="number"
                    value={row.count}
                    onChange={(e) => updateDistRow(i, { count: Number(e.target.value) })}
                  />
                  <button onClick={() => removeDistRow(i)} className="text-red-500 px-3">✕</button>
                </div>
              ))}
            </div>
            {distribution.length > 0 && (
              <p className="text-[12px] text-[var(--ink-soft)] mt-2">
                Distribution total: {distTotal} / {totalQuestions}
              </p>
            )}
          </div>

          {error && <p className="text-[12.5px] text-red-500">{error}</p>}
          <button onClick={handleCreate} disabled={loading || !name} className="btn btn-primary">
            {loading ? "Creating..." : "Create Test"}
          </button>
        </div>
      )}

      <div className="card overflow-x-auto">
        <table className="w-full text-[13.5px]">
          <thead>
            <tr className="text-left text-[var(--ink-soft)] border-b border-[var(--line)]">
              <th className="p-4">Test Name</th>
              <th className="p-4">Duration</th>
              <th className="p-4">Questions</th>
              <th className="p-4">Passing %</th>
              <th className="p-4">Status</th>
              <th className="p-4">Actions</th>
            </tr>
          </thead>
          <tbody>
            {exams.map((exam) => (
              <tr key={exam._id} className="border-b border-[var(--line)] last:border-0">
                <td className="p-4 font-medium">{exam.name}</td>
                <td className="p-4">{exam.durationMinutes} min</td>
                <td className="p-4">{exam.totalQuestions}</td>
                <td className="p-4">{exam.passingPercentage}%</td>
                <td className="p-4">
                  <button
                    onClick={() => toggleActive(exam)}
                    className={exam.isActive ? "text-green-600 font-medium" : "text-[var(--ink-soft)] font-medium"}
                  >
                    {exam.isActive ? "Active" : "Inactive"}
                  </button>
                </td>
                <td className="p-4">
                  <button onClick={() => handleDelete(exam._id)} className="text-red-500 font-medium hover:underline">
                    Delete
                  </button>
                </td>
              </tr>
            ))}
            {exams.length === 0 && (
              <tr><td colSpan={6} className="p-8 text-center text-[var(--ink-soft)]">No tests created yet.</td></tr>
            )}
          </tbody>
        </table>
      </div>
    </AdminLayout>
  );
};

export default AdminExams;
