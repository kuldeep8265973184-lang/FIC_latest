import { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { useAuth } from "@/context/AuthContext";
import { fetchActiveExams } from "@/services/api/exam.service";
import { startExamAttempt } from "@/services/api/exam.service";
import { fetchMyResults } from "@/services/api/attempt.service";
import { getIcon } from "@/constants/iconMap";
import logo from "@/assets/images/logo.png";
import type { ExamConfig, ExamResult } from "@/types";

const LogOutIcon = getIcon("arrowRight");
const AwardIcon = getIcon("award");
const ClockIcon = getIcon("clock");
const CheckIcon = getIcon("checkCircle");
const BookIcon = getIcon("bookOpen");

const StudentDashboard = () => {
  const { student, logout } = useAuth();
  const navigate = useNavigate();
  const [exams, setExams] = useState<ExamConfig[]>([]);
  const [results, setResults] = useState<ExamResult[]>([]);
  const [loading, setLoading] = useState(true);
  const [startingId, setStartingId] = useState<string | null>(null);
  const [error, setError] = useState("");

  useEffect(() => {
    Promise.all([fetchActiveExams(), fetchMyResults()])
      .then(([e, r]) => {
        setExams(e || []);
        setResults(r || []);
      })
      .finally(() => setLoading(false));
  }, []);

  const attemptedExamIds = new Set(results.map((r) => (typeof r.exam === "string" ? r.exam : r.exam._id)));

  const handleStartTest = async (examId: string) => {
    setError("");
    setStartingId(examId);
    try {
      const paper = await startExamAttempt(examId);
      if (paper) navigate(`/exam/${paper.attemptId}`);
    } catch (err: any) {
      setError(err?.response?.data?.message || "Could not start the test. Please try again.");
    } finally {
      setStartingId(null);
    }
  };

  return (
    <div className="min-h-screen bg-[var(--bg-soft)]">
      <header className="grad-navy py-6">
        <div className="container-x flex items-center justify-between">
          <Link to="/" className="flex items-center gap-3">
            <img src={logo} alt="Future IT College logo" className="w-10 h-10 rounded-xl object-cover bg-white" />
            <p className="font-display font-bold text-white text-[15px]">Future IT College</p>
          </Link>
          <button onClick={logout} className="btn btn-outline btn-sm">
            <LogOutIcon size={15} /> Logout
          </button>
        </div>
      </header>

      <div className="container-x py-10">
        <div className="card p-8 rounded-[var(--radius-lg)] mb-8">
          <p className="text-[13px] text-[var(--ink-soft)] font-medium">Welcome back,</p>
          <h1 className="font-display font-bold text-2xl lg:text-3xl mt-1">{student?.name}</h1>
          <div className="grid sm:grid-cols-3 gap-4 mt-6">
            <div className="flex items-center gap-3">
              <div className="icon-wrap"><BookIcon size={20} /></div>
              <div>
                <p className="text-[12px] text-[var(--ink-soft)]">Course</p>
                <p className="font-medium text-[14px]">{student?.course || "Not set"}</p>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <div className="icon-wrap"><AwardIcon size={20} /></div>
              <div>
                <p className="text-[12px] text-[var(--ink-soft)]">Tests Completed</p>
                <p className="font-medium text-[14px]">{results.length}</p>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <div className="icon-wrap"><CheckIcon size={20} /></div>
              <div>
                <p className="text-[12px] text-[var(--ink-soft)]">Email</p>
                <p className="font-medium text-[14px]">{student?.email}</p>
              </div>
            </div>
          </div>
        </div>

        {error && (
          <div className="rounded-xl bg-red-50 border border-red-200 text-red-600 text-[13.5px] px-4 py-3 mb-6">
            {error}
          </div>
        )}

        <div className="grid lg:grid-cols-2 gap-8">
          <div>
            <h2 className="font-display font-semibold text-xl mb-4">My Tests / Upcoming Tests</h2>
            {loading ? (
              <div className="card p-6 h-32 ph" />
            ) : exams.length === 0 ? (
              <div className="card p-6 text-[13.5px] text-[var(--ink-soft)]">No tests available right now.</div>
            ) : (
              <div className="space-y-4">
                {exams.map((exam) => {
                  const attempted = attemptedExamIds.has(exam._id);
                  return (
                    <div key={exam._id} className="card p-6 flex items-center justify-between gap-4">
                      <div>
                        <h3 className="font-display font-semibold text-[15px]">{exam.name}</h3>
                        <p className="text-[12.5px] text-[var(--ink-soft)] mt-1 flex items-center gap-2">
                          <ClockIcon size={13} /> {exam.durationMinutes} min · {exam.totalQuestions} Questions ·{" "}
                          {exam.difficulty}
                        </p>
                      </div>
                      <button
                        onClick={() => handleStartTest(exam._id)}
                        disabled={(attempted && !exam.allowRetest) || startingId === exam._id}
                        className="btn btn-primary btn-sm shrink-0"
                      >
                        {attempted && !exam.allowRetest
                          ? "Attempted"
                          : startingId === exam._id
                          ? "Starting..."
                          : "Start Test"}
                      </button>
                    </div>
                  );
                })}
              </div>
            )}
          </div>

          <div>
            <h2 className="font-display font-semibold text-xl mb-4">Previous Results</h2>
            {loading ? (
              <div className="card p-6 h-32 ph" />
            ) : results.length === 0 ? (
              <div className="card p-6 text-[13.5px] text-[var(--ink-soft)]">
                You haven't attempted any tests yet.
              </div>
            ) : (
              <div className="space-y-4">
                {results.map((r) => (
                  <Link
                    key={r._id}
                    to={`/result/${r._id}`}
                    className="card p-6 flex items-center justify-between gap-4 block hover:!translate-y-[-2px]"
                  >
                    <div>
                      <h3 className="font-display font-semibold text-[15px]">
                        {typeof r.exam === "string" ? "Test" : r.exam.name}
                      </h3>
                      <p className="text-[12.5px] text-[var(--ink-soft)] mt-1">
                        {r.correct}/{r.totalQuestions} correct · {r.percentage}%
                      </p>
                    </div>
                    <span
                      className={`text-[12px] font-semibold px-3 py-1.5 rounded-full ${
                        r.isPassed ? "bg-green-50 text-green-700" : "bg-red-50 text-red-600"
                      }`}
                    >
                      {r.isPassed ? "Pass" : "Fail"}
                    </span>
                  </Link>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default StudentDashboard;
