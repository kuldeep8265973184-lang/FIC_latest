import api from "./axiosInstance";
import type { ApiResponse, ExamConfig } from "@/types";

export const fetchAllExams = async () => {
  const res = await api.get<ApiResponse<ExamConfig[]>>("/admin/exams");
  return res.data.data;
};

export const createExam = async (payload: Partial<ExamConfig>) => {
  const res = await api.post<ApiResponse<ExamConfig>>("/admin/exams", payload);
  return res.data.data;
};

export const updateExam = async (id: string, payload: Partial<ExamConfig>) => {
  const res = await api.put<ApiResponse<ExamConfig>>(`/admin/exams/${id}`, payload);
  return res.data.data;
};

export const deleteExam = async (id: string) => {
  await api.delete(`/admin/exams/${id}`);
};
